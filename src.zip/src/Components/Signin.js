import React, {useState } from 'react'
import { Link } from 'react-router-dom';

function Signin() {

    const [emptyEmail,setEmptyEmail]=useState(false);
    const [validEmail,setValidEmail]=useState(false);

   const  func1 =()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email").value;
    if(x===""){
    setEmptyEmail(true);
    }
    if (x.match(validRegex)) {
        setEmptyEmail(false);
        setValidEmail(false);
       }
      else if(x!==""){
        setValidEmail(true);
        setEmptyEmail(false);
      }
      else{
        setEmptyEmail(true);
        setValidEmail(false);
      }


   }

   let emailkey =()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email").value;

    if (x.match(validRegex)) {
    setEmptyEmail(false);
    setValidEmail(false);
   }
  else if(x!==""){
    setValidEmail(true);
    setEmptyEmail(false);
  }
  else{
    setEmptyEmail(true);
    setValidEmail(false);
  }
  
   }

   let emailChange= ()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email").value;

    if(x!==""){
    if(!validRegex.test(x)){
        
        setValidEmail(true);
    }}
   }

   const [err2,setErr2]=useState(false);

   const  func2 =()=>{
    let x = document.getElementById("password").value;
    if(x===""){
    setErr2(true);
    }
   }

   let passkey =()=>{
    setErr2(false);
    let x = document.getElementById("password").value;
    if(x!==""){
        setErr2(false);
    }
   }

   const Submit =()=>{
    
    let email= document.getElementById("email").value;
    let pass=document.getElementById('password').value;

    if(email==="" ){
        setEmptyEmail(true);
    }
    
    if(pass==="" ){
        setErr2(true);
    }
    


   }



  return (
 
  
<div  className="flex min-h-full items-center justify-center py-20 px-4 sm:px-6 lg:px-8">
  <div  className="w-full max-w-md space-y-8">
    <div>
      <img  className="mx-auto h-12 w-auto" src="	https://dashboard.kiwify.com.br/_nuxt/img/kiwify-green-logo.2af0e50.png" alt="Your Company"/>
      <h2  className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">Login to your account</h2>
      <p  className="mt-2 text-center text-sm text-gray-600">
        Or
        <Link to="Register"  className="font-medium text-indigo-600 hover:text-indigo-500"> register</Link>
      </p>
    </div>
    <div  className="mt-8 sm:mx-auto sm:w-full sm:max-w-md"><form  onSubmit={Submit} className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10"><div><label htmlFor="email"  className="block text-sm font-medium leading-5 mb-1 text-gray-700">
            E-mail
          </label> <div>  <input type="text" onChange={emailChange} onKeyPress={emailkey} autoComplete="username" id='email' name="email" onBlur={func1} className="form-input block py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5 w-full"/>
          {emptyEmail&& (
                  <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
                )}


                {
                    validEmail  &&  (
                        <p className="text-red-500 text-sm mt-1">
                          The email must be valid
                        </p>
                      )
                }
           </div>  </div> <div  className="mt-6"><label htmlFor="password"  className="block text-sm font-medium leading-5 text-gray-700">
            
            <font ><font >
                
          Password
          </font></font></label> <div>  <input type="password" onKeyPress={passkey} id='password' onBlur={func2} autoComplete="current-password" name="password"  className="form-input block py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5 w-full"/>  
          {err2 && (
                  <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
                )}
          </div></div> <div  className="mt-2 flex items-center justify-end"><div  className="text-sm leading-5"><a href="/"  className="font-medium text-indigo-600 hover:text-indigo-500 focus:outline-none focus:underline transition ease-in-out duration-150"><font ><font >
              Forgot password?
            </font></font></a></div></div> 
          
            
              <div  className="mt-6"><span  className="block w-full rounded-md shadow-sm"><button type="button"  className="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo active:bg-indigo-700 transition duration-150 ease-in-out"> <font ><font >To enter
            </font></font></button></span></div></form></div>
  </div>
</div>

  )
}

export default Signin
