import React, {useState } from 'react'
import { Link } from 'react-router-dom';

function Register() {

    const [epmtyEmail, setEmptyEmail]=useState(false);
    const [validCheck,setValidCheck]=useState(false);

   const  EmailBlur =()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let email = document.getElementById("email").value;
    if(email===""){
     setEmptyEmail(true);
     setValidCheck(false);
    }
    if (email.match(validRegex)) {
         setEmptyEmail(false);
         setValidCheck(false);
       }
      else if(email!==""){
         setValidCheck(true);
         setEmptyEmail(false);
      }
      else{
         setEmptyEmail(true);
         setValidCheck(false);
      }


   }

   let Email_One_KeyPress=()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let email = document.getElementById("email").value;
     setEmptyEmail(false);
    if (email.match(validRegex)) {
     setEmptyEmail(false);
     setValidCheck(false);
   }
  else if(email!==""){
     setValidCheck(true);
     setEmptyEmail(false);
  }
  else{
     setEmptyEmail(true);
     setValidCheck(false);
  }
  
   }

   let emailChange= ()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let email = document.getElementById("email").value;

     setEmptyEmail(false);
     setValidCheck(false);

    if(email===""){
         setEmptyEmail(true);
    }
    if(email!==""){
    if(!validRegex.test(email)){
        
         setValidCheck(true);
    }}
   }

   const [epmtyEmail2,setEmptyEmail2]=useState(false);
   const [err_email2_correct,setErr_email2_correct]=useState(false);
   const [err_sameEmail,setSameEmail]=useState(false);

   const  function2 =()=>{
    
    setSameEmail(true);

    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email2").value;
    let y =document.getElementById("email").value;

    if(x===y && x!==""){
        setSameEmail(false);
    }
    if(x===""){
        setEmptyEmail2(true);
        setErr_email2_correct(false);

    }
    if (x.match(validRegex)) {
        setEmptyEmail2(false);
        setErr_email2_correct(false);
       }
      else if(x!==""){
        setErr_email2_correct(true);
        setEmptyEmail2(false);
      }
      else{
        setEmptyEmail2(true);
        setErr_email2_correct(false);
      }


   }

   let emailkey2 =()=>{
    setEmptyEmail2(false);
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email2").value;
    let y =document.getElementById("email").value;
    
    if(x===y){
        setSameEmail(false);
    }
    if (x.match(validRegex)) {
        setEmptyEmail2(false);
        setErr_email2_correct(false);
   }
  else if(x!==""){
    setErr_email2_correct(true);
    setEmptyEmail2(false);
  }
  else{
    setEmptyEmail2(true);
    setErr_email2_correct(false);
  }
  
   }

   let emailChange2= ()=>{
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let x = document.getElementById("email2").value;
  
    let y =document.getElementById("email").value;
    
    if(x===y){
        setSameEmail(false);
    }
    
    setEmptyEmail2(false);
    setErr_email2_correct(false);

    if(x===""){
        setEmptyEmail2(true);
    }

    if(x!==""){
    if(!validRegex.test(x)){
        
        setErr_email2_correct(true);
    }}
   }

   const [err2,setErr2]=useState(false);

   const  func2 =()=>{
    let x = document.getElementById("password").value;
    if(x===""){
    setErr2(true);
    }
   }

   let passkey =()=>{
    setErr2(false);
    let x = document.getElementById("password").value;
    if(x!==""){
        setErr2(false);
    }
   }

   const [isChecked, setIsChecked] = useState(false);
   const [ click, setClick] = useState(false);
   
const clicking =()=>{

setClick(true);

}

  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
  }
   
  const [alert,setAlert]=useState(false);

const Submit=()=>{

  setAlert(false);

    let email= document.getElementById("email").value;
    let email2= document.getElementById("email2").value;
    let pass=document.getElementById('password').value;

    if(email===""){
         setEmptyEmail(true);
    }
    if(email2===""){
        setEmptyEmail2(true);
    }

    if(pass===''){
        setErr2(true);
    }

   if(click===false){
    setClick(true);
   }

    if( !epmtyEmail && !epmtyEmail2  && !err2  && click ){
       let pass =  document.getElementById("password").value;
       if(pass.length<8 && pass!==""){
        setAlert(true);
       }
    }
} 

  return (
    <div>
      <div  className="flex min-h-full items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
  <div  className="w-full max-w-md space-y-8">
    <div>
      <img  className="mx-auto h-12 w-auto" src="	https://dashboard.kiwify.com.br/_nuxt/img/kiwify-green-logo.2af0e50.png" alt="Your Company"/>
      <h2  className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">create new account</h2>
      <p  className="mt-2 text-center text-sm text-gray-600">
        Or
        <Link to="/"  className="font-medium text-indigo-600 hover:text-indigo-500"> sign into your existing account</Link>
      </p>
    </div>
    
    <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md"><div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10"><div><label className="block text-sm font-medium leading-5 mb-1 text-gray-700"><font ><font >
            E-mail
          </font></font></label> <div>   <input type="text" onChange={emailChange} onKeyPress={ Email_One_KeyPress} id="email" onBlur={EmailBlur} autoComplete="off" name="null" className="form-input block py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5 w-full"/>  
          {epmtyEmail && (
                  <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
                )}

{
                    validCheck &&  (
                        <p className="text-red-500 text-sm mt-1">
                          The email must be valid
                        </p>
                      )
                }

           </div>   </div> <div className="mt-6"><label className="block text-sm font-medium leading-5 mb-1 text-gray-700"><font ><font>
          
            repeat email
          </font></font></label> <div>   <input type="email" id="email2" onBlur={function2} onChange={emailChange2} onKeyPress={emailkey2} autoComplete="off" name="null" className="form-input block py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5 w-full"/>
   
          {
                  err_sameEmail &&  (
                        <p className="text-red-500 text-sm mt-1">
                          The two emails must be the same.
                        </p>
                      )
                }

   
          {epmtyEmail2 && (
                  <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
                )}

{
                    err_email2_correct &&  (
                        <p className="text-red-500 text-sm mt-1">
                          The email must be valid
                        </p>
                      )
                }
             </div>   </div> <div className="mt-6"><label className="block text-sm font-medium leading-5 text-gray-700"><font ><font >
            Password
          </font></font></label> <div>   <input type="password" onKeyPress={passkey} id='password' onBlur={func2} autoComplete="off" name="null" className="form-input block py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5 w-full"/>   </div></div>
          {err2 && (
                  <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
                )}

           <div className="mt-6"><label className="relative flex items-start mt-2"><div className="flex items-center h-5"><input  type="checkbox" checked={isChecked} onClick={clicking} onChange={handleCheckboxChange}  className="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out cursor-pointer"/> </div> 
        
          <div className="ml-2 text-sm leading-5"><span className="font-medium text-gray-700"><font ><font >I have read and accept </font><font >Kiwify's </font></font><a href="https://kiwify.com.br/termos-de-uso" target="_blank"  rel="noreferrer" className="underline"><font ><font >terms of use</font></font></a><font ><font > , </font></font><a href="https://kiwify.com.br/licenca-de-uso-software" rel="noreferrer" target="_blank" className="underline"><font ><font >software license terms</font></font></a><font ><font > , </font></font><a href="https://kiwify.com.br/politica-de-conteudo" rel="noreferrer" target="_blank" className="underline"><font ><font >content policy</font></font></a><font ></font></span>  
          {!isChecked  &&  click &&
        (
            <p className="text-red-500 text-sm mt-1">
                    This field is mandatory
                  </p>
        )
      }
           </div></label></div>  
          { alert && (
           <div className="mt-4 bg-red-50 border-l-4 border-red-400 p-4 mb-8"><div className="flex items-center"><div className="flex-shrink-0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="24px" height="24px" className="text-red-400"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg></div> <div className="ml-3"><p className="text-sm leading-5 text-red-700">
          auth/weak-password
        </p></div></div></div>
          )
          }
             <div className="mt-6"><span className="block w-full rounded-md shadow-sm"><button onClick={Submit} className="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo active:bg-indigo-700 transition duration-150 ease-in-out">  <font ><font >Create an account
            </font></font></button></span></div></div></div>
           

  </div>
</div>
    </div>
  )
}

export default Register
