
import './App.css';
import Signin from './Components/Signin';
import { Route } from 'react-router-dom';
import { BrowserRouter, Routes  } from 'react-router-dom';
import Register from './Components/Register';

function App() {
  return (
   <>
   
   <BrowserRouter>
   <Routes>
   <Route path="/" element={   <Signin/>} />
   <Route path="/Register" element={   <Register/>} />
   </Routes>
</BrowserRouter>

   </>
  );
}

export default App;
